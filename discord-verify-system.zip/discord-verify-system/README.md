# Discord Verify System

A Discord.js v14 bot and an Express OAuth2 verification website. The member explicitly authorizes Discord OAuth2 (`identify` and `guilds.join`); the server then joins the configured guild and grants the configured verified role.

## 1. Create the Discord application

1. Create an application at https://discord.com/developers/applications.
2. Under **OAuth2 > General**, add this exact redirect URI after you deploy: `https://YOUR-RENDER-SERVICE.onrender.com/auth/callback`.
3. Copy the Application ID and Client Secret.
4. Under **Bot**, create/reset the bot token. Keep it secret.
5. Invite the bot to your server with `bot` and `applications.commands` scopes. Give it **Manage Roles** and permission to send messages/embed links in the verification channel. Do not grant Administrator.
6. Enable **Server Members Intent** under Bot > Privileged Gateway Intents.
7. In your server, create a role such as `Verified`. Move the bot's highest role above `Verified`.

## 2. Deploy with GitHub + Render

1. Create a GitHub repository and upload all files in this folder.
2. In Render, create a **Web Service** connected to that repository.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`.
4. Add all variables from `.env.example` in Render's Environment settings. `BASE_URL` and `OAUTH_REDIRECT_URI` must use the actual Render URL. No trailing slash on `BASE_URL`.
5. After deployment, add the exact callback URL to Discord Developer Portal > OAuth2 > Redirects, then redeploy if needed.
6. Open `https://YOUR-RENDER-SERVICE.onrender.com/health`; it should return `{"ok":true}`.

## 3. Configure IDs

- `DISCORD_GUILD_ID`: your server ID (enable Developer Mode in Discord, then Copy Server ID).
- `VERIFIED_ROLE_ID`: ID of the role to grant (Copy Role ID).
- `DISCORD_CLIENT_ID`: Application ID.
- `DISCORD_CLIENT_SECRET`: OAuth2 Client Secret.
- `DISCORD_BOT_TOKEN`: Bot token.

Never paste secrets into GitHub. Commit only `.env.example`, not your real `.env` file.

## 4. Use it

1. Invite the bot to the configured server.
2. Run `/setup-verify` and select the verification channel and the same role configured in `VERIFIED_ROLE_ID`.
3. Members press the link button, review the Discord authorization screen, and approve it.
4. The website validates the one-use OAuth state, reads the authorized profile, adds the member to the configured server, grants the role, and displays the success page.

## Important notes

- The OAuth page is hosted by Discord. This site never asks for Discord passwords or bot tokens from members.
- The app requests `identify` and `guilds.join`. `guilds.join` is used to add the consenting account to the configured server. Explain this clearly to members.
- The bot must have Manage Roles, and its highest role must be above the Verified role.
- This starter stores short-lived OAuth state in process memory. For multi-instance hosting or strict production requirements, use a shared database/Redis with TTL and add monitoring, backups, and privacy disclosures.
- Configure a real privacy policy URL in the Discord Developer Portal before public distribution.
