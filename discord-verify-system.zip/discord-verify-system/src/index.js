require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const { rateLimit } = require('express-rate-limit');
const crypto = require('node:crypto');
const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  Client,
  EmbedBuilder,
  GatewayIntentBits,
  PermissionFlagsBits,
  REST,
  Routes,
  SlashCommandBuilder
} = require('discord.js');

const required = [
  'DISCORD_CLIENT_ID', 'DISCORD_CLIENT_SECRET', 'DISCORD_BOT_TOKEN',
  'DISCORD_GUILD_ID', 'VERIFIED_ROLE_ID', 'BASE_URL', 'OAUTH_REDIRECT_URI'
];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

const {
  DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, DISCORD_BOT_TOKEN,
  DISCORD_GUILD_ID, VERIFIED_ROLE_ID, BASE_URL, OAUTH_REDIRECT_URI
} = process.env;
const baseUrl = BASE_URL.replace(/\/$/, '');
const app = express();
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

app.disable('x-powered-by');
app.set('trust proxy', 1); // Render terminates HTTPS at its proxy
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: '10kb' }));
const authLimiter = rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false });

// Short-lived, one-use OAuth state values. Never put tokens or user data in the URL.
const pendingStates = new Map();
const STATE_TTL_MS = 10 * 60 * 1000;
setInterval(() => {
  const now = Date.now();
  for (const [state, record] of pendingStates) {
    if (record.expiresAt <= now) pendingStates.delete(state);
  }
}, 60_000).unref();

function page(title, body) {
  return `<!doctype html>
<html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title}</title><style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:22px;background:radial-gradient(circle at 50% 0,#641515 0,#210909 42%,#090909 100%);color:#f7eeee;font-family:Arial,'Noto Sans Thai',sans-serif}
.card{width:min(100%,520px);padding:34px 26px;border:1px solid #713030;border-radius:28px;background:linear-gradient(145deg,rgba(75,20,20,.96),rgba(15,8,8,.98));box-shadow:0 18px 65px #0009;text-align:center}
.logo{width:86px;height:86px;border:5px solid #d83a3a;border-radius:50%;margin:0 auto 24px;background:#180b0b;display:grid;place-items:center;font-size:34px;font-weight:800;color:#ff6666}
.kicker{letter-spacing:3px;color:#d98a8a;font-size:13px}.title{font-size:32px;margin:12px 0}.sub{color:#e5aaaa;font-size:19px}.profile{margin:28px 0;padding:24px 14px;border:1px solid #633131;border-radius:22px;background:#ffffff09}.avatar{width:112px;height:112px;border:5px solid #df4545;border-radius:50%;object-fit:cover}.username{font-size:27px;font-weight:700;margin:16px 0 8px;overflow-wrap:anywhere}.success{color:#75df91;font-size:20px;font-weight:700}.note{color:#d4bcbc;line-height:1.8}.status{padding:17px;border:1px solid #396a43;border-radius:16px;color:#83e29b;font-weight:700;margin:22px 0}.btn{display:block;text-decoration:none;background:linear-gradient(#c52e2e,#851919);padding:17px;border-radius:15px;color:white;font-size:18px;font-weight:700;margin-top:18px}.error{color:#ff9b9b}.small{font-size:12px;color:#a88c8c;margin-top:24px}
</style></head><body><main class="card"><div class="logo">V</div><div class="kicker">SERVER VERIFY</div>${body}<div class="small">Discord Verification • Secure OAuth2</div></main></body></html>`;
}

app.get('/', (_req, res) => res.type('html').send(page('Discord Verify', '<h1 class="title">Discord Verification</h1><p class="note">เปิดลิงก์ยืนยันตัวตนจากปุ่มใน Discord เพื่อดำเนินการต่อ</p>')));

app.get('/health', (_req, res) => res.json({ ok: true }));

app.get('/verify', authLimiter, (_req, res) => {
  const state = crypto.randomBytes(32).toString('hex');
  pendingStates.set(state, { expiresAt: Date.now() + STATE_TTL_MS });
  const params = new URLSearchParams({
    client_id: DISCORD_CLIENT_ID,
    redirect_uri: OAUTH_REDIRECT_URI,
    response_type: 'code',
    scope: 'identify guilds.join',
    state,
    prompt: 'consent'
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

app.get('/auth/callback', authLimiter, async (req, res) => {
  const { code, state, error } = req.query;
  if (error) return res.status(400).type('html').send(page('Authorization cancelled', '<h1 class="title">ยกเลิกการอนุญาต</h1><p class="note">คุณยังไม่ได้ยืนยันตัวตน สามารถกลับไปเริ่มใหม่จาก Discord ได้</p>'));
  if (typeof code !== 'string' || typeof state !== 'string') {
    return res.status(400).type('html').send(page('Invalid request', '<h1 class="title error">ลิงก์ไม่ถูกต้อง</h1><p class="note">กรุณากลับไปเริ่มจากปุ่ม Verify ใน Discord</p>'));
  }
  const pending = pendingStates.get(state);
  pendingStates.delete(state); // one use, even if the callback fails
  if (!pending || pending.expiresAt < Date.now()) {
    return res.status(400).type('html').send(page('Expired request', '<h1 class="title error">ลิงก์หมดอายุ</h1><p class="note">กรุณากลับไปกด Verify ใน Discord อีกครั้ง</p>'));
  }

  try {
    const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        client_secret: DISCORD_CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: OAUTH_REDIRECT_URI
      })
    });
    const tokenData = await tokenResponse.json();
    if (!tokenResponse.ok || !tokenData.access_token) throw new Error('OAuth token exchange failed');

    const userResponse = await fetch('https://discord.com/api/v10/users/@me', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` }
    });
    const user = await userResponse.json();
    if (!userResponse.ok || !user.id) throw new Error('Could not read Discord profile');

    // Join the configured server using the member's explicit guilds.join consent.
    const joinResponse = await fetch(`https://discord.com/api/v10/guilds/${DISCORD_GUILD_ID}/members/${user.id}`, {
      method: 'PUT',
      headers: {
        Authorization: `Bot ${DISCORD_BOT_TOKEN}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ access_token: tokenData.access_token })
    });
    if (!joinResponse.ok && joinResponse.status !== 204) {
      const detail = await joinResponse.text();
      console.error('Guild join failed:', joinResponse.status, detail.slice(0, 300));
      throw new Error('Could not add account to the configured Discord server');
    }

    const guild = await client.guilds.fetch(DISCORD_GUILD_ID);
    const member = await guild.members.fetch(user.id);
    const role = await guild.roles.fetch(VERIFIED_ROLE_ID);
    if (!role) throw new Error('Configured verified role was not found');
    await member.roles.add(role, 'Member completed Discord OAuth2 verification');

    const avatar = user.avatar
      ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=256`
      : `https://cdn.discordapp.com/embed/avatars/${Number(BigInt(user.id) >> 22n) % 6}.png`;
    const safeName = String(user.global_name || user.username).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
    const body = `<h1 class="title">Verify Success</h1><div class="sub">ยืนยันตัวตนสำเร็จ</div><section class="profile"><img class="avatar" src="${avatar}" alt="Discord avatar"><div class="username">${safeName}</div><div class="success">Success Member</div></section><p class="note">ระบบยืนยันตัวตนของคุณเรียบร้อยแล้ว<br>คุณได้รับยศ Verified ในเซิร์ฟเวอร์แล้ว</p><div class="status">✓ Account Verified</div><a class="btn" href="https://discord.com/channels/${DISCORD_GUILD_ID}">กลับสู่ Discord</a>`;
    return res.type('html').send(page('Verify Success', body));
  } catch (err) {
    console.error('Verification error:', err.message);
    return res.status(500).type('html').send(page('Verification failed', '<h1 class="title error">Verification Failed</h1><p class="note">ระบบยังดำเนินการไม่สำเร็จ กรุณาตรวจสอบการตั้งค่าบอทและลองใหม่อีกครั้ง</p><a class="btn" href="/verify">ลองอีกครั้ง</a>'));
  }
});

client.once('ready', async () => {
  console.log(`Bot logged in as ${client.user.tag}`);
  const command = new SlashCommandBuilder()
    .setName('setup-verify')
    .setDescription('สร้างแผงยืนยันตัวตนในห้องที่เลือก')
    .addChannelOption((option) => option.setName('channel').setDescription('ห้องที่จะส่งแผง Verify').setRequired(true))
    .addRoleOption((option) => option.setName('role').setDescription('ยศที่จะมอบหลังยืนยัน').setRequired(true));
  const rest = new REST({ version: '10' }).setToken(DISCORD_BOT_TOKEN);
  await rest.put(Routes.applicationGuildCommands(DISCORD_CLIENT_ID, DISCORD_GUILD_ID), { body: [command.toJSON()] });
  console.log('Slash command /setup-verify registered.');
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isChatInputCommand() || interaction.commandName !== 'setup-verify') return;
  if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
    return interaction.reply({ content: 'คุณต้องมีสิทธิ์ Manage Server เพื่อใช้คำสั่งนี้', ephemeral: true });
  }
  const channel = interaction.options.getChannel('channel');
  const role = interaction.options.getRole('role');
  if (!channel?.isTextBased() || !channel.send) {
    return interaction.reply({ content: 'กรุณาเลือกห้องข้อความ', ephemeral: true });
  }
  if (role.id !== VERIFIED_ROLE_ID) {
    return interaction.reply({ content: `ยศที่เลือกไม่ตรงกับ VERIFIED_ROLE_ID ที่ตั้งไว้ใน Hosting`, ephemeral: true });
  }
  const guild = interaction.guild;
  const botMember = await guild.members.fetchMe();
  if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles) || role.position >= botMember.roles.highest.position) {
    return interaction.reply({ content: 'บอทต้องมีสิทธิ์ Manage Roles และยศบอทต้องอยู่สูงกว่ายศ Verified', ephemeral: true });
  }
  const embed = new EmbedBuilder()
    .setColor(0xD93636)
    .setTitle('กดรับยศ')
    .setDescription('ยืนยันตัวตนเพื่อรับยศ\n\nกดปุ่มด้านล่างเพื่อยืนยันกับ Discord')
    .setImage('https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=80')
    .setFooter({ text: 'Server Verification' });
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setLabel('verify').setStyle(ButtonStyle.Link).setURL(`${baseUrl}/verify`)
  );
  await channel.send({ embeds: [embed], components: [row] });
  return interaction.reply({ content: `สร้างแผง Verify ใน ${channel} เรียบร้อยแล้ว`, ephemeral: true });
});

const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', () => console.log(`Verification website listening on ${port}`));
client.login(DISCORD_BOT_TOKEN);
